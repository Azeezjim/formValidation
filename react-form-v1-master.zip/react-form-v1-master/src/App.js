import React from 'react';
import './App.css';
import Form from './Form';

function App() {
  return <Form />;
}

export default App;
